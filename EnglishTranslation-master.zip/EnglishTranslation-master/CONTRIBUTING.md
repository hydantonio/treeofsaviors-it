Thank you for your contribution to the Tree of Savior English Open Text Client Repository.
<br>Merging of your pull request is conditioned on your acceptance to the <a href="https://cla-assistant.io/Treeofsavior/EnglishTranslation"> Contributor Agreement</a>.
<br>Please indicate that you acknowledge, understand and accept the terms of Contributor Agreement by clicking on the "Agree" button in the <a href="https://cla-assistant.io/Treeofsavior/EnglishTranslation"> Contributor Agreement</a>.
<br>If you disagree to the terms of the Contributor Agreement, please do not send us any pull requests.
